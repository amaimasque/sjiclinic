<?php
	mysqli_close($con);
?>