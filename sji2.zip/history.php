<!DOCTYPE html>
<html>
<head>
	<title>View clientele</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="images/logo_img.png">
	<link rel="stylesheet" href="css/w3.css">
	<link rel="stylesheet" href="css/jquery.dataTables.min.css"/>
    <script type="text/javascript" src="js/jquery-3.3.1.js"></script>
    <link data-require="font-awesome@*" data-semver="4.5.0" rel="stylesheet" href="css/sjiclinic.css" />
	<style type="text/css">
		thead tr th{
			padding-top: 20px;
		}
		td.details-control {
		    background: url('../resources/details_open.png') no-repeat center center;
		    cursor: pointer;
		}
		tr.shown td.details-control {
		    background: url('../resources/details_close.png') no-repeat center center;
		}
	</style>
</head>
<body>
	<?php
		require("nav_admin.php");
		$viewby  = $_GET["viewby"];
		if($viewby==""){ $viewby = "client"; }	
	?>

	<div class="w3-container" style="padding: 200px;">
		<div class="w3-row">
			<div class="w3-col l8 m12 s12"><h4 style="font-weight: 900; color: #833438">Clients Master List</h4></div>
			<div class="w3-col l2 m6 s6">
				<a href="history.php?viewby=client" class="w3-button w3-border" style="width: 100%;" id="btn_client">CLIENT</a>
			</div>
			<div class="w3-col l2 m6 s6">
				<a href="history.php?viewby=visits" class="w3-button w3-border" style="width: 100%" id="btn_visits">VISITS</a>
			</div>
		</div>
		
		<table id="example" class="display w3-table w3-border w3-striped w3-container" style="width:100%">
	        <thead>
	        	<?php
	        		if($viewby=="client"){
	        	?>
	        		<script type="text/javascript">
	        			$(document).ready(function(){
	        				$("#btn_client").addClass("w3-light-grey");
	        			});	        			
	        		</script>
		            <tr class="w3-light-grey w3-center">
		                <th>ID</th>
		                <th>Client Name</th>
		                <th>Address</th>
		                <th>Contact Number</th>
		                <th>No. of Pets</th>
		                <th>Action</th>
		            </tr>
	            <?php
	            	}else if($viewby=="visits"){
	        	?>
	        		<script type="text/javascript">
	        			$(document).ready(function(){
	        				$("#btn_visits").addClass("w3-light-grey");
	        			});	        			
	        		</script>
		            <tr class="w3-light-grey w3-center">
						<th>ID</th>
						<th>Date</th>
						<th>Client</th>
						<th>Pet</th>
						<th>Service</th>
						<th>Action</th>
					</tr>
	            <?php
	            	}else
	            ?>
	        </thead>
	        <tbody class="w3-center">
	        	<?php
	        		if($viewby=="client"){
	        	?>
	        		<script type="text/javascript">
	        			$(document).ready(function(){
	        				$("#btn_client").addClass("w3-light-grey");
	        			});	        			
	        		</script>
		           	<tr>
		        		<td>1</td>
		        		<td>Analia</td>
		        		<td>Lingayen, Pangasinan</td>
		        		<td>09999999999</td>
		        		<td>1</td>
		        		<td>
		        			<a href="viewclient.php" class="w3-button w3-border" style="width: 80%"><i class="demo-icon icon-view"></i> VIEW</a>
		        		</td>
		        	</tr>
	            <?php
	            	}else if($viewby=="visits"){
	        	?>
	        		<script type="text/javascript">
	        			$(document).ready(function(){
	        				$("#btn_visits").addClass("w3-light-grey");
	        			});	        			
	        		</script>
					<tr>
		        		<td>1</td>
		        		<td>5/1/2019</td>
		        		<td>Analia</td>
		        		<td>Kia</td>
		        		<td>Grooming</td>
		        		<td>
		        			<a href="viewclient.php" class="w3-button w3-border" style="width: 80%"><i class="demo-icon icon-view"></i> VIEW</a>
		        		</td>
		        	</tr>
	            <?php
	            	}else
	            ?>
	        	
	        </tbody>
	    </table>
	</div>

	<script type="text/javascript">
		 $(document).ready(function() {
			$("#history").addClass("button_active");
			$('#example').DataTable();
		} );
    </script>
    <script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
</body>
</html>