<?php
	require('db_connection.php');

	$clientID;
	$petID;

	if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['new'])) {
		$cfname = test_input($_POST["client_fname"]);
		$cmname = test_input($_POST["client_mname"]);
		$clname = test_input($_POST["client_lname"]);
		$caddress = test_input($_POST["client_address"]);
		$ccontact = test_input($_POST["client_contact"]);

		$pname = test_input($_POST["pet_name"]);
		$pbdate = test_input($_POST["pet_bdate"]);
		$psex = test_input($_POST["pet_sex"]);
		$pspecies = test_input($_POST["pet_species"]);
		$pbreed = test_input($_POST["pet_breed"]);
		$pcolor = test_input($_POST["pet_color_markings"]);
		$pvet = test_input($_POST["pet_vet"]);
		$newpetid;
	}

	if(isset($_POST['new'])){
		$ownerid = insertClient();
		$last_petid = insertPatient($ownerid);
		echo "New Client";
	}

	function insertPatient(){
		global $con, $sql;
		$sql = $con->prepare("INSERT INTO tbl_pets (pet_name, pet_birthdate, pet_sex, pet_species, pet_breed, pet_color_markings, pet_previous_vet, pet_owner_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
		$sql->bind_param("sssssssi", $pname, $pbdate, $psex, $pspecies, $pbreed, $pcolor, $pvet, $ownerid);
		if ($sql->execute() === TRUE) {
		    $last_id = $con->insert_id;
		    return $last_id;
		} else {
		    echo "Error: " . $sql . "<br>" . $con->error;
		}
	}

	function insertClient($ownerid){
		global $con, $sql;
		$sql = $con->prepare("INSERT INTO tbl_clients (client_firstname, client_middlename, client_lastname, client_address, client_contactnumber) VALUES (?, ?, ?, ?, ?)");
		$sql->bind_param("ssssss", $cfname, $cmname, $clname, $caddress, $ccontact);
		if ($sql->execute() === TRUE) {
		    $last_id = $con->insert_id;
		    return $last_id;
		} else {
		    echo "Error: " . $sql . "<br>" . $con->error;
		}
	}

	if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['old'])){
		getClient();
	}

	function getClient(){
		$ocid = test_input($_POST["oclient_id"]);
		$ocname = test_input($_POST["oclient_name"]);
		$opid = test_input($_POST["opet_id"]);
		$opname = test_input($_POST["opet_name"]);
	}

	if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['apt'])){
		insertService($_POST['apt']);
	}

	function insertService($aptType){
		//get id of pet
		global $last_petid, $con, $sql;
		$sql = $con->prepare("INSERT INTO tbl_service (patient_id , service_type, service_apt_date) VALUES (?, ?, ?)");
		$sql->bind_param("iss", $last_petid, $aptType, date("Y-m-d H:i:s"));
		//get service id
		if ($sql->execute() === TRUE) {
		    $last_serviceid = $con->insert_id;
		} else {
		    echo "Error: " . $sql . "<br>" . $con->error;
		}
		if ($aptType == 'consultation') {
			$cattitude = test_input($_POST["attitude"]);
			$cdrinking = test_input($_POST["drinking"]);
			$cbowels = test_input($_POST["bowels"]);
			$ccoughing = test_input($_POST["coughing"]);
			$curination = test_input($_POST["urination"]);
			$cappetite = test_input($_POST["appetite"]);
			$cvomiting = test_input($_POST["vomiting"]);
			$csneezing = test_input($_POST["sneezing"]);
			$ccnotes = test_input($_POST["cnotes"]);
			
			$sql = $con->prepare("INSERT INTO tbl_consultation (service_id, consultation_attitude, consultation_drinking, consultation_bowels, consultation_coughing, consultation_urination, consultation_appetite, consultation_vomiting, consultation_sneezing, consultation_notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			$sql->bind_param("isssssssss", $last_serviceid, $cattitude, $cdrinking, $cbowels, $ccoughing, $curination, $cappetite, $cvomiting, $csneezing, $ccnotes);
			$sql->execute();
		} elseif ($aptType == 'surgery') {
			# code...
		} elseif ($aptType == 'vaccine') {
			# code...
		} elseif ($aptType == 'grooming') {
			# code...
		}

	}

	require('closedb_connection.php');
?>